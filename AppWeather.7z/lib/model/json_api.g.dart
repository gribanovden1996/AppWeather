// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'json_api.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$JsonApiImpl _$$JsonApiImplFromJson(Map<String, dynamic> json) =>
    _$JsonApiImpl(
      current: Current.fromJson(json['current'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$JsonApiImplToJson(_$JsonApiImpl instance) =>
    <String, dynamic>{
      'current': instance.current,
    };
