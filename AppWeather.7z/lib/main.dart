import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:weather1/data/http_openweathermap.dart';
import 'package:weather1/data/http_weatherapi.dart';

import 'data/navig.dart';


void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) =>
    //Provider<Http_openweathermap>(
    Provider<HttpWeatherApi>(
      // create: (BuildContext context) { return Http_openweathermap(); },
      create: (BuildContext context) { return HttpWeatherApi(); },
      child:
        MaterialApp(
          title: 'Weather',
          theme: ThemeData(
            colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
            useMaterial3: true,
          ),
          onGenerateRoute: Routes,
        ),
     );
}